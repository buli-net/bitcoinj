#
# Reproducible reference build
#
# Usage:
#
# buildah build --file build.Containerfile --output <outputdir> .
# or
# podman build --file build.Containerfile --output <outputdir> .
# or
# docker build --file build.Containerfile --output <outputdir> .
#
# The build artifacts are written to the specified output directory.
# To also run tests, add
#
# --build-arg ADDITIONAL_GRADLE_TASK=test
#

# stage: set up debian environment
FROM debian:bookworm-slim AS setup-stage

ENV DEBIAN_FRONTEND noninteractive
RUN --mount=target=/var/lib/apt/lists,type=cache,sharing=locked \
    --mount=target=/var/cache/apt,type=cache,sharing=locked \
    /usr/bin/rm -f /etc/apt/apt.conf.d/docker-clean && \
    /usr/bin/apt-get update && \
    /usr/bin/apt-get --yes --no-install-recommends install openjdk-17-jdk-headless gradle && \
    /usr/sbin/adduser --disabled-login --gecos "" builder

# stage: build
FROM setup-stage AS build-stage

ARG ADDITIONAL_GRADLE_TASK=""

# give up privileges
USER builder
WORKDIR /home/builder

# copy project source code
COPY --chown=builder / project/

# build project
RUN --mount=target=/home/builder/.gradle,type=cache,uid=1000,gid=1000,sharing=locked \
    /usr/bin/gradle --project-dir project/ \
    --no-build-cache --no-daemon --no-parallel \
    -Dmaven.repo.local=repo \
    clean ${ADDITIONAL_GRADLE_TASK} :bitcoinj-core:publishToMavenLocal :bitcoinj-wallettool:installDist

# stage: export build output
FROM scratch AS export-stage
COPY --from=build-stage \
    /home/builder/repo/org/bitcoinj/*/*/*.jar \
    /home/builder/repo/org/bitcoinj/*/*/*.pom \
    /core/
COPY --from=build-stage \
    /home/builder/project/wallettool/build/install/wallet-tool/ \
    /wallettool/
